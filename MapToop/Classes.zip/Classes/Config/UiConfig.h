﻿
#ifndef __UiConfig_H_
#define __UiConfig_H_
#if (__HeadFileIncludeNum == __HeadFileHavePath)
#include "Ui/Ui_GroupListView.h"
#include "Ui/Ui_StringNotice.h"
#else
#include "Ui_GroupListView.h"
#include "Ui_StringNotice.h"
#endif
#endif